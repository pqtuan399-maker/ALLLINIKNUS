# ALLLINKNUS

Bản HTML này được mở rộng trực tiếp từ file bạn gửi ngày 08/10/2026. Có 5 thẻ liên kết: Đăng ký thường, Đăng ký đột xuất, Link Công Khai, Link Drive và Ban Thánh Nhạc NUS.

## Tải file lên GitHub

1. Giải nén `ALLLINKNUS_GITHUB.zip`.
2. Trong repository đang dùng, thay `index.html` bằng bản mới và tải thêm đúng 3 ảnh:
   - `icon-link-cong-khai.png`
   - `icon-link-drive.png`
   - `icon-ban-thanh-nhac.png`
3. Đặt HTML và các PNG cùng thư mục gốc. Giữ nguyên 4 ảnh đang dùng: `icon.png`, `logo-nha-ung-sinh.png`, `icon-dang-ky-thuong.png`, `icon-dang-ky-dot-xuat.png`. Gói ZIP cũng có sẵn các ảnh này lấy từ trang hiện tại của bạn.
4. Commit các thay đổi. Tải các file đã giải nén; không tải riêng file ZIP lên repository.

## Đổi tên repository

Vào repository `DANGKYXUATANNUS` → **Settings → General → Repository name**, đổi thành **ALLLINKNUS** rồi bấm **Rename**.

Kiểm tra **Settings → Pages** vẫn dùng nhánh chứa `index.html` và thư mục **/(root)**. Khi bản triển khai hoàn tất, truy cập:

https://pqtuan399-maker.github.io/ALLLINKNUS/

Đây là địa chỉ dự kiến sau khi bạn đổi tên và triển khai. Bộ file này chưa tự thay đổi repository hay website của bạn.

GitHub Pages không tự chuyển hướng URL trang dự án cũ khi đổi tên repository. Hãy cập nhật các link và mã QR đã chia sẻ. Biểu tượng đã thêm vào màn hình chính hoặc thanh tác vụ có thể vẫn trỏ tới đường dẫn cũ; nếu không mở đúng trang mới, hãy thêm/cài lại từ link ALLLINKNUS.

## Nội dung giữ lại

- Logo Nhà Ứng Sinh, favicon/icon màn hình chính và hai icon đăng ký bữa ăn.
- Hai đường dẫn đăng ký thường và đăng ký đột xuất, lấy đúng từ HTML bạn gửi.
- Hai ghi chú “21h15 khóa đăng ký” và “Chú ý mã OTP”. Ghi chú giờ khóa chỉ là chữ hiển thị; HTML không điều khiển lịch khóa trong Google Sheets.
- Câu Kinh Thánh Mt 6,11 và hiệu ứng khi chạm vào thẻ.
- Liên kết mở trong cùng tab/cửa sổ, như bản HTML gốc. Dùng nút Quay lại để trở về trang liên kết.

## Ba thẻ mới

| Thẻ | Nội dung | Icon |
| --- | --- | --- |
| Link Công Khai | Cập nhật thông tin ứng sinh | Hồ sơ và danh sách |
| Link Drive | Lịch học chi tiết | Lịch, thư mục và sách |
| Ban Thánh Nhạc NUS | Soạn nhạc, lịch bắt nhịp, lịch đánh đàn, dạy hát | Khóa Sol, nốt nhạc và đàn |

Cả ba đường dẫn mới được chép nguyên văn từ yêu cầu của bạn, gồm cả phần `gid` của Google Sheets.

## Giao diện và sử dụng

Điện thoại hiển thị 5 thẻ theo chiều dọc. Laptop hiển thị 2 thẻ bữa ăn và 3 thẻ thông tin/sinh hoạt theo các cột. Trang không dùng thư viện, font hay JavaScript từ bên ngoài. Tên file ảnh là đường dẫn tương đối nên tiếp tục hoạt động khi đổi tên repository.

Quyền truy cập các bảng tính và thư mục Drive vẫn do Google quyết định. Tên “Link Công Khai” không tự cấp quyền xem cho người chưa được chia sẻ. Bộ HTML không thay đổi dữ liệu, Apps Script, trigger hay bảo vệ ô. Các ảnh icon được tạo bằng công cụ tạo ảnh theo phong cách hai icon có sẵn.

## Tài liệu GitHub

Đổi tên repository: https://docs.github.com/en/repositories/creating-and-managing-repositories/renaming-a-repository

GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
